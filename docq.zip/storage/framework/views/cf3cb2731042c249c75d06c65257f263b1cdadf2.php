<html>
<head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link href="<?php echo e(asset('Admin/css/app.css')); ?>" rel="stylesheet">
</head>
<body>
<div id="app"></div>

<script src="<?php echo e(asset('Admin/js/app.js')); ?>" type="application/javascript"></script>
</body>
</html>