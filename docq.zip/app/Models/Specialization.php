<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property string specialization_value
 */
class Specialization extends Model
{

}
