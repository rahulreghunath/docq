<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property string week_day
 */
class WeekDay extends Model
{
    //
}
