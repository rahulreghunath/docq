<?php

namespace App\Http\Controllers\API\IVRS;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class IVRSApiController extends Controller
{
    //
}
