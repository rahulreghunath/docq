<?php


namespace App\Services\User;


use App\Services\Service;
use Illuminate\Http\Request;

class UserService extends Service
{
    public function newRegistration(Request $request)
    {

    }
}