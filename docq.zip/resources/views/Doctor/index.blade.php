<html>
<head>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link href="{{ asset('Admin/css/style.css') }}" rel="stylesheet">
</head>
<body>
<div id="app"></div>

<script src="{{ asset('Doctor/js/app.js') }}" type="application/javascript"></script>
</body>
</html>