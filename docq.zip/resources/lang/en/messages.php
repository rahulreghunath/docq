<?php

return [
    'patient_edited' => 'Patient details updated successfully.',
    'patient_added' => 'Patient added successfully.',
    'schedule_deleted' => 'Schedule deleted successfully.',
    'schedule_added' => 'Schedule added successfully.',
    'status_update' => 'Status updated successfully',
];